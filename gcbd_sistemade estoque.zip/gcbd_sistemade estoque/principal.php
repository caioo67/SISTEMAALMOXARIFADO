
  <body>
  <section style="background: #eaeaea;" id="container">

    <section id="main-content">
      <section style="" class="wrapper site-min-height">
        <div class="row mt">
        



<div class="col-lg-12">
            <div class="row content-panel">
              <div class="col-md-4 profile-text mt mb centered">
                <div class="right-divider hidden-sm hidden-xs">
                  <h4>E-mail</h4>
                  <h6>2018infor07@gmail.com</h6>

                  <h4>Telefone</h4>
                  <h6>(85) 9-9187-3201</h6>
                
                </div>
              </div>
              <!-- /col-md-4 -->
              <div class="col-md-4 profile-text">
                <h3>JMF</h3>
               
                <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC.</p>
                <br>
              </div>
              <!-- /col-md-4 -->
              <div class="col-md-4 centered">
                <div class="profile-pic">
                  <p><img src="img/icon.jpg" class="img-circle"></p>
                
                </div>
              </div>
              <!-- /col-md-4 -->
            </div>
            <!-- /row -->
          </div>
          <!-- /col-lg-12 -->







          <!-- /col-lg-12 -->
          <div class="col-lg-12 mt">
            <div class="row content-panel">
              
              <!-- /panel-heading -->
              <div class="panel-body">
                <div class="tab-content">
                  <div id="overview" class="tab-pane active">
                    <div class="row">



                      <div class="col-md-6 detailed">
                         <h4>AVISO PARA OS USUÁRIOS</h4>

                         <form action="" method="post">
                         <textarea name="lembrar" style="margin-top: 5%;" rows="3" class="form-control" placeholder="O que você precisa lembrar?"></textarea>

                        <div class="grey-style">
                          <div class="pull-right">
                            <button  type="submit"name="BotaoLembrar"  class="btn btn-sm btn-theme03 call_trigger_blue" >Publicar</button>
                          </div>
                        </div>

                         
                         </form>
                       

                         <?php
include_once('conect/conect.php');
            if(isset($_POST['BotaoLembrar'])){
              $lembrar = trim(strip_tags($_POST['lembrar']));
            
              $lembrete = "INSERT INTO mensagem (lembrar) VALUES (:lembrar)";

                    try{
                       $result = $conect->prepare($lembrete);
                        $result->bindParam(':lembrar',$lembrar,PDO::PARAM_STR);
                        $result->execute();

                        $contar = $result->rowCount();
                        if($contar>0){
                          echo '<div class="alert alert-success" role="alert">Aviso adicionadado!</div>';
                        }else{
                          echo '<div class="alert alert-danger" role="alert">Ocorreu algum erro!</div>';
                        }
                    }catch(PDOException $e){
                        echo "<b>ERRO DE PDO= </b>".$e->getMessage();
                    }
            }
          ?>




                        <div class="detailed mt">
                          <h4>ATIVIDADES RECENTES</h4>
                          <div class="recent-activity">
                            <div class="activity-icon bg-theme"><i class="fa fa-check"></i></div>
                            <div class="activity-panel">
                              <h5>ÚLTIMA HORA</h5>
                              <p>Retirada de 5 pincéis</p>
                            </div>
                            <div class="activity-icon bg-theme02"><i class="fa fa-trophy"></i></div>
                            <div class="activity-panel">
                              <h5>ÚLTIMO DIA</h5>
                              <p>Cadastro de um novo usúario</p>
                            </div>
                            <div class="activity-icon bg-theme04"><i class="fa fa-rocket"></i></div>
                            <div class="activity-panel">
                              <h5>ÚLTIMA SEMANA</h5>
                              <p>Retirada de 5 unidades de detergente</p>
                            </div>
                          </div>
                          <!-- /recent-activity -->
                        </div>
                        <!-- /detailed -->
                      </div>
                      <!-- /col-md-6 -->




                      <div class="col-md-6 detailed">
                        <h4>+ retirados</h4>
                        <div class="row centered mt mb">






              <?php
      $select = "SELECT * FROM meletrico WHERE id LIMIT 0,2";
      try{
        $result = $conect->prepare($select);
          $result->execute();
          $contar = $result->rowCount();
          if ($contar>0) {
            while($show = $result->FETCH(PDO::FETCH_OBJ)){
              
    ?>





                         <div class="col-sm-4">
                            <h1><i class="fa fa-wrench"></i></h1>
                            <h3>10</h3>
                            <h6>   <?php echo $show->nome;?></h6>
                          </div>




              <?php
            
            }
} else {
echo '<div class="alert alert-danger" role="alert">Não há dados!
</div>';
}
}catch(PDOException $e){
echo "<b>Erro de select do PDO</b>".$e->getMessage();
}

?>







                          


                          <div class="col-sm-4">
                            <h1><i class="fa fa-qrcode"></i></h1>
                            <h3>1</h3>
                            <h6>RETIRADA DE PENDRIVE</h6>
                          </div>



                          <div class="col-sm-4">
                            <h1><i class="fa fa-lightbulb-o"></i></h1>
                            <h3>1</h3>
                            <h6> RETIRADA DE LAMPADA</h6>
                          </div>


                        </div>
                        <!-- /row -->
                        <h4>Ultimos Usuários</h4>
                        <div class="row centered mb" style="margin-left: 30%;">
                          <ul class="my-friends" >








                            <li>
                              <div class="friends-pic"><img class="img-circle" width="35" height="35" src="img/friends/fr-01.jpg"></div>
                            </li>
                            <li>
                              <div class="friends-pic"><img class="img-circle" width="35" height="35" src="img/friends/fr-02.jpg"></div>
                            </li>
                            <li>
                              <div class="friends-pic"><img class="img-circle" width="35" height="35" src="img/friends/fr-03.jpg"></div>
                            </li>
                            <li>
                              <div class="friends-pic"><img class="img-circle" width="35" height="35" src="img/friends/fr-04.jpg"></div>
                            </li>
                            <li>
                              <div class="friends-pic"><img class="img-circle" width="35" height="35" src="img/friends/fr-05.jpg"></div>
                            </li>
                      
                          </ul>
                          
                        </div>
                        <!-- /row -->

 <h4 style="margin-top: 5%;">LEMBRETE </h4>



 <form action="" method="post">
 
 <textarea name="msmalerta" rows="3" class="form-control" placeholder="O que você precisa lembrar?"></textarea>
                        <div class="grey-style">

                          <div class="pull-right">
                            <button type="submit" name="botaoalerta" class="btn btn-sm btn-theme03">Publicar</button>
                          </div>
                        </div>
 
 
 
 </form>
                   





                        <?php
include_once('conect/conect.php');
            if(isset($_POST['botaoalerta'])){
              $msmalerta = trim(strip_tags($_POST['msmalerta']));
            
              $alerta = "INSERT INTO alerta (msmalerta) VALUES (:msmalerta)";

                    try{
                       $result = $conect->prepare($alerta);
                        $result->bindParam(':msmalerta',$msmalerta,PDO::PARAM_STR);
                        $result->execute();

                        $contar = $result->rowCount();
                        if($contar>0){
                          echo '<div class="alert alert-success" role="alert">Aviso adicionadado!</div>';
                        }else{
                          echo '<div class="alert alert-danger" role="alert">Ocorreu algum erro!</div>';
                        }
                    }catch(PDOException $e){
                        echo "<b>ERRO DE PDO= </b>".$e->getMessage();
                    }
            }
          ?>








                      </div>
                      <!-- /col-md-6 -->





    <div class="row centered">            
       

      </div>


                    </div>
                    <!-- /OVERVIEW -->
                  </div>
                  <!-- /tab-pane -->
                  
                 
                  <!-- /tab-pane -->
                </div>
                <!-- /tab-content -->
              </div>
              <!-- /panel-body -->
            </div>
            <!-- /col-lg-12 -->
          </div>


          <!-- /row -->
        </div>
        <!-- /container -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->

    <!--footer end-->
  </section>
  

<!-- ADMIN LTE 3-->



<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="_cdn/script.js"></script>