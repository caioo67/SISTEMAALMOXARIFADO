

<?php
ob_start();
session_start();
if (!isset($_SESSION['loginUser']) && (!isset($_SESSION['senhaUser']))) {
  header("Location: index.php?acao=negado");
  exit;
}
include_once('includes/sair.php');
?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Gestor Estoque</title>


  <!-- ICONE DA PÁGINA -->
  <link href="img/ui-sam.jpg" rel="icon">
  <link href="img/icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="css/zabuto_calendar.css">
  <link rel="stylesheet" type="text/css" href="lib/gritter/css/jquery.gritter.css" />
    <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
  <script src="lib/chart-master/Chart.js"></script>






</head>

<body>




<?php
		include_once('conect/conect.php');
		$userEmail = $_SESSION['loginUser'];
      	$senhaUser = $_SESSION['senhaUser'];
      	$select = "SELECT * FROM admin WHERE email=:emailUser AND senha=:senhaUser";
      	try{
      	$resultado = $conect->prepare($select);
      	$resultado->bindParam(':emailUser',$userEmail,PDO::PARAM_STR);
        $resultado->bindParam(':senhaUser',$senhaUser,PDO::PARAM_STR);
        $resultado->execute();
        //CONTA REGISTRO
        $contar = $resultado->rowCount();
        if ($contar > 0) {
          while ($show = $resultado->FETCH(PDO::FETCH_OBJ)) {
            $id = $show->id;
            $nome = $show->nome;
            $email = $show->email;
            $fone = $show->fone;
            $cpf = $show->cpf;
            $senha = $show->senha;
            $avatar = $show->avatar;
            $status = $show->status;
          }
        } else {
        	header("Location:  ?sair");
        }
        
      	}catch(PDOException $e){
        echo "<b>ERRO DE PDO NO SELECT: </b>".$e->getMessage();
      }
	?>



  <section id="container">
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Fechar menu"></div>
      </div>







      <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Fechar menu"></div>
      </div>
      <!--logo start-->
      <a href="home.php?acao=principal" class="logo"><b>ALMO<span>XARIFADO</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">
    
          <!-- inbox dropdown start-->
          <li id="header_inbox_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="">
              <i class="fa fa-envelope-o"></i>
              <span class="badge bg-theme">5</span>
              </a>
            <ul class="dropdown-menu extended inbox">
              <div class="notify-arrow notify-arrow-green"></div>
              <li>
                <p style="margin-bottom: 15px;" class="green">Você tem 5 novas mensagens</p>
              </li>



              <?php
      $select = "SELECT admin.avatar, admin.nome, mensagem.lembrar FROM admin, mensagem WHERE admin.id = mensagem.idlembrar";
      try{
        $result = $conect->prepare($select);
          $result->execute();
          $contar = $result->rowCount();
          if ($contar>0) {
            while($show = $result->FETCH(PDO::FETCH_OBJ)){
              
    ?>


 
              <li>
                <a href="index.html#">
                  <span class="photo"> <img alt="avatar"src="img/<?php echo $show->avatar;?>">  </span>
                  <span class="subject">
                  <span class="from"><?php echo $show->nome;?></span>
                  <span class="time">status</span>
                  </span>
                  <span class="message">
                   <?php echo $show->lembrar;?>
                  </span>
                  </a>
              </li>




              <?php
            
            }
} else {
echo '<div class="alert alert-danger" role="alert">Não!
</div>';
}
}catch(PDOException $e){
echo "<b>Erro de select do PDO</b>".$e->getMessage();
}

?>


            </ul>
          </li>



          



 <li id="header_notification_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="">
              <i class="fa fa-bell-o"></i>
              <span class="badge bg-warning">7</span>
              </a>
            <ul class="dropdown-menu extended notification">
              <div class="notify-arrow notify-arrow-yellow"></div>
              <li>
                <p class="yellow">You have 7 new notifications</p>
              </li>




  <?php

      $select = "SELECT * FROM alerta ORDER BY id DESC";

      try{
        $result = $conect->prepare($select);
          $result->execute();
          $contar = $result->rowCount();
          if ($contar>0) {
            while($show = $result->FETCH(PDO::FETCH_OBJ)){
              
    ?>

                
                    

                    <li>
                                  <a href="paginas/delete/deleteAlerta.php?deletar=<?php  echo $show->id;?>  " onclick="return confirm('Deseja realmente deletar o Registro')">
                                    <span class="label label-danger"><i class="fa fa-bolt"></i></span>
                                 <?php echo $show->msmalerta;?> 
                                    <span class="small italic">4 mins.</span>
                                    </a>
                                </li>


             




       <?php
            
            }
} else {
echo '<div class="alert alert-danger" role="alert">Não há dados!
</div>';
}
}catch(PDOException $e){
echo "<b>Erro de select do PDO</b>".$e->getMessage();
}

?>

            </ul>
          </li>




          <!-- notification dropdown end -->



 <li id="header_notification_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="">
              <i class="fa fa-warning sx  "></i>
              <span class="badge bg-warning">7</span>
              </a>
            <ul class="dropdown-menu extended notification">
              <div class="notify-arrow notify-arrow-yellow"></div>
              <li>
                <p class="yellow">Alerta do estoque</p>
              </li>



              <?php
           $select = "SELECT * FROM meletrico ORDER BY id DESC";
            try{
              $result = $conect->prepare($select);
                $result->execute();
                $contar = $result->rowCount();
            
                if ($contar>0 ) { 
                  while($show = $result->FETCH(PDO::FETCH_OBJ)){                     
       


                    

                       $verificar = $show->qtdMinima;
                       $verificarProduto = $show->qtdProduto;


                    if ($verificarProduto<$verificar) {
                   
 

?>

                         <li>
                      <a href="#">
                        <span class="label label-danger" ><i class="fa fa-lightbulb-o"></i></span>

<?php echo $show->nome;?> no limite
                    </a>
                  </li>
                   <?php 

                    } 


           
                                           
                      }
          } else {
          echo '<div class="alert alert-danger" role="alert">NOT DADES
          </div>';
          }
          }catch(PDOException $e){
          echo "<b>Erro de select do PDO</b>".$e->getMessage();
          }

          ?>


















            </ul>
          </li>

        </ul>
        <!--  notification end -->












      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="?sair"   onclick="return confirm('Deseja realmente sair do sistema?')">Sair</a></li>
        </ul>
      </div>
    </header>

    </header>
 
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="home.php?acao=profile "><img src="img/1.jpg" class="img-circle" width="80"></a></p>
          <h5 class="centered">Hidan</h5>
       
                          <li class="sub-menu">
                              <span><a href="home.php?acao=relatorio"> <i class="fa  fa-bar-chart-o"></i>Relatório</a></span>        
                          </li>
                       
                          <li class="sub-menu">
                            <a href="javascript:;">
                              <i class="fa fa-dropbox"></i>
                              <span>Produtos</span>
                              </a>

                            <ul class="sub">
                              <li><a href="home.php?acao=limpeza">Material limpeza</a></li>
                              <li><a href="home.php?acao=eletrico"> Material de eletrico </a></li>
                              <li><a href="home.php?acao=processamentoDados">Processamento de dados</a></li>
                              <li><a href="home.php?acao=expediente"> Material de expediente</a></li> 
                              <li><a href="home.php?acao=eletrico2"> eletrico2</a></li> 
                            </ul>

                          </li>

                          <li class="sub-menu">
                              <span><a href="home.php?acao=configuracao"> <i class="fa  fa-cogs"></i>Configurações</a></span>        
                          </li>


        </ul>
      </div>
    </aside>

    





 
 


 


 