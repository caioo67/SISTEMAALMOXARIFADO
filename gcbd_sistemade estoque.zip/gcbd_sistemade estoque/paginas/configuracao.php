
   <section style="background: #eaeaea;" id="main-content">
      <section class="wrapper site-min-height">
     
  

<div class="row mt">
<div class="col-lg-12">


            <div class="row content-panel">
              <div class="profile-text mt mb centered">
                <div class="right-divider hidden-sm hidden-xs">
                
 <div  class="detailed" style="margin-top: 4%;"><h4>EDITAR ACESSO</h4></div>



 <table class="table display" id="minhaTabela">
                          <thead>
                                  <tr>                    
                                   <th scope="col" ></th>           
                                    <th scope="col" >Nome</th>                               
                                    <th scope="col">Status</th>
                                    <th scope="col">Excluir</th>
                                    <th scope="col">Editar</th>
                                  </tr>
                          </thead>

                          <tbody>

                          <?php
      $select = "SELECT * FROM admin ORDER BY id DESC";
      try{
        $result = $conect->prepare($select);
          $result->execute();
          $contar = $result->rowCount();
          if ($contar>0) {
            while($show = $result->FETCH(PDO::FETCH_OBJ)){
    ?>
                                  <tr>   

                                    <td> 
                                    <img style=" text-align: center; border-radius: 100%; width: 50px" src="img/<?php echo $show->avatar;?>">
                                    </td>
                                    <td>
                                    <h4 style="color: #5bc0de; font-weight: bolder;"> <?php echo $show->nome;?> </h4>
                                    </td>
                              <td style="font-style: italic;"> 
                              
                              <?php           
      $status = $show->status;
      if($status==0){
        echo 'Acesso negado';
      }elseif ($status == 1) {
        echo 'Diretor';
      }elseif ($status == 2) {
        echo 'Coordenador(a)';
      }elseif ($status == 3) {
        echo 'Secretario(a)';
      }
      else{
        echo 'Administrador';
      }
    ?></td>
                                     <td><a href="paginas/delete/deleteUser.php?deletar=<?php echo $show ->id ?>" class="btn btn-danger" onclick="return confirm('Deseja realmente deletar o Registro')"><i class="fa fa-trash-o"></i></a></td>
                             
                              <td><button id="adicionarNOVO" type="button" class="btn btn-info" data-toggle="modal" data-target=".bd-exemplo-modal-sm">  <i class="fa fa-pencil" ></i>        </button></td>

                                  </tr>

                                  <?php

}
} else {
echo '<div class="alert alert-danger" role="alert">Não há dados!
</div>';
}
}catch(PDOException $e){
echo "<b>Erro de select do PDO</b>".$e->getMessage();
}

?>



                           </tbody>
                      </table>






                   </div>
                </div>
              </div>

                   


<!-- MODAL EDITAR-->
<div class="modal fade bd-exemplo-modal-sm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelEDitar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabelEDitar">Editar</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form  method="POST">

         <div class="form-group">
              <label class="col-form-label">Nivel de acesso:</label>
              <select style="width:250px; font-size: 13px" name="status"  class="form-control">
                <option value="" disabled="" selected="">Selecione o nível</option>
                <option value="1">Diretor</option>
                <option value="2">Coordenador(a)</option>
                <option value="3">Secretária</option>
              </select>
          </div>

          

        

          <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                  <button type="submit" name="botao" class="btn btn-warning">Salvar mudanças</button>
          </div>

</form>
      </div>
      
    </div>
  </div>
</div> 
<!-- FIM DO MODAL EDITAR-->


<?php
            if(isset($_POST['botao'])){
              $status = trim(strip_tags($_POST['status']));
    
             

              $update = "UPDATE admin SET status=:status WHERE id=:id";

                    try{
                      $result = $conect->prepare($update);
                      $result->bindParam(':id',$id,PDO::PARAM_INT);
                        $result->bindParam(':status',$status,PDO::PARAM_STR);
                     
                 
                        $result->execute();

                        $contar = $result->rowCount();
                        if($contar>0){
                          echo '<div class="alert alert-success" role="alert">Dados atualizados com sucesso!</div>';
                        }else{
                          echo '<div class="alert alert-danger" role="alert">Dados não atualizados!</div>';
                        }
                    }catch(PDOException $e){
                        echo "<b>ERRO DE PDO= </b>".$e->getMessage();
                    }
            }
          ?>











<!--EXLUIR ALERTA -->
            <div class="row content-panel" style="margin-top: 7%;">
              <div class="profile-text mt mb centered">
                <div class="right-divider hidden-sm hidden-xs">
                
 <div  class="detailed" style="margin-top: 4%;"><h4>EXCLUIR MENSAGEM</h4></div>



 





                   </div>
                </div>
              </div>
<!--EXLUIR ALERTA -->







<!-- EDICAO DOS DADOS DA ESCOLA -->
    <div class="row content-panel" style="margin-top: 7%;">
              <div class="profile-text mt mb centered">
                <div class="right-divider hidden-sm hidden-xs">
                
 <div  class="detailed" style="margin-top: 4%;"><h4>EDITAR DADOS DA ESCOLA</h4></div>


 





                   </div>
                </div>
              </div>
<!-- FIM EDICAO DOS DADOS DA ESCOLA -->







      </section>
      <!-- /wrapper -->
    </section>











 
