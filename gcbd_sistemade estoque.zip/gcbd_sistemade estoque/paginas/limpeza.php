

   <section id="main-content">
      <section class="wrapper site-min-height">
        <h3><i class="fa fa-angle-right"></i> Material de Limpeza</h3>

        <button style="margin-left:93%;" id="adicionarNOVO" type="button" class="btn btn-theme"  data-toggle="modal" data-target="#exampleModal" data-whatever="@fat"> <i class="fa fa-plus-square-o" 
       ></i>  Novo
        </button>


<!-- MODAL DE PEDIDOS-->


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">

        <h5 class="modal-title" id="exampleModalLabel">Adicionar Produto</h5>

       <button type="button" class="close" data-dismiss="modal" aria-label="Close"> 
          <span aria-hidden="true">&times;</span> 
        </button>

      </div>

<div class="modal-body">

    <form id="adiciona_produtos">

               <div class="form-group">
                      <label for="nome_limpeza" class="col-form-label">Nome:</label>
                      <input type="text" class="form-control" id="nome_limpeza" name="nome_limpeza" placeholder="Digite o nome do produto...">
               </div>

               <div class="form-group">
                      <label for="nome_limpeza" class="col-form-label">Quantidade:</label>
                      <input type="text" class="form-control" id="nome_limpeza" name="nome_limpeza" placeholder="">
               </div>

              
          <div class="form-group">
              <label class="col-form-label">Quantidade miníma de produtos</label>
              <select style="width:250px; font-size: 13px" name="genero"  class="form-control">
                <option value="" disabled="" selected="">Selecione a quantidade</option>
                <option value="05">05</option>
                <option value="10">10</option>
                <option value="15">15</option>
                <option value="20">20</option>
              </select>
          </div>

    

               <div class="form-group">
                      <label for="data">Válidade</label>
                      <div class="form-inline">
                        <div class="form-group mx-2">
                           <div class=input-group>
                            <input class=form-control name="sum_vacant-gte" type="date">
                            <span style="background: #4ECDC4; color: #fff;"  class=input-group-addon> <i class="fa fa-calendar"></i> </span> 

                           </div>
                        </div>
                      </div>
              </div>

      </div>


   </form>



      <div class="modal-footer">

          <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button> 
          <button type="button" class="btn btn-warning">Adicionar</button>

      </div>
    </div>
  </div>
</div> <!-- FIM DO MODAL DE PEDIDOS-->
  

<div class="row mt">
<div class="col-lg-12">

                          <table class="table table-striped" id="minhaTabela">
                          <thead>
                          <tr> 	

                 
                            <th>Nome</th>
                            <th>Quantidade</th>
                            <th>Validade</th>
                            <th>Ação</th>
                            <th>Retirar</th>
                            <th>Editar</th>
                          </tr>
                          </thead>
                          <tbody>

                          <tr>
                           
                            <td>Vinicius Moura</td>
                            <td>1</td>
                            <td>1</td>
                            <td>       <button id="adicionarNOVO" type="button" class="btn btn-danger"> <i class="fa fa-trash-o"></i></button></td>
                      <td><button id="adicionarNOVO" type="button" class="btn btn-warning"  data-toggle="modal" data-target=".bd-example-modal-sm"> <i class="fa fa-minus-square-o"></i></button></td>
                      <td><button id="adicionarNOVO" type="button" class="btn btn-success" data-toggle="modal" data-target=".bd-exemplo-modal-sm">  <i class="fa fa-pencil" ></i>        </button></td>

                          </tr>
                          </tbody>
                          </table>




<!-- MODAL DO RETIRAR-->
<div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
     <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"> Editar produto</h5>
       <button type="button" class="close" data-dismiss="modal" aria-label="Close"> 
          <span aria-hidden="true">&times;</span> 
        </button>
      </div>
    <form>

 <div style="margin-left: 7%; " class="form-group">
            <label for="" class="col-form-label">Quantidade:</label>
            <input class="" type="text" class="form-control" id="" placeholder="Quantidade de produtos...">
          </div>


</form>
<div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button> 
        <button type="button" class="btn btn-warning">Retirar</button>
      </div>


    </div>
</div>
</div>
<!-- FIM MODAL DO RETIRAR-->

<!-- MODAL EDITAR-->

<!-- Modal -->
<div class="modal fade bd-exemplo-modal-sm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelEDitar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabelEDitar">Editar</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form>

<div class="form-group">
  <label for="" class="col-form-label">Nome:</label>
  <input type="text" class="form-control" id="" placeholder="Digite o nome do produto...">
</div>

<div class="form-group">
  <label for="" class="col-form-label">Quantidade:</label>
  <input type="text" class="form-control" id="" placeholder="">
</div>





<div class="form-group ">
<label for="data">Válidade</label>
<div class="form-inline">


<div class="form-group mx-2">
<div class=input-group>
<input class=form-control name="sum_vacant-gte" type="date">
<span style="background: #4ECDC4; color: #fff;"  class=input-group-addon> <i class="fa fa-calendar"></i> </span>                </div>
</div>


</div>

</div>

          <div class="form-group">
              <label class="col-form-label">Quantidade miníma de produtos</label>
              <select style="width:250px; font-size: 13px" name="genero"  class="form-control">
                <option value="" disabled="" selected="">Selecione a quantidade</option>
                <option value="05">05</option>
                <option value="10">10</option>
                <option value="15">15</option>
                <option value="20">20</option>
              </select>
          </div>




</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
        <button type="button" class="btn btn-warning">Salvar mudanças</button>
      </div>
    </div>
  </div>
</div> 
<!-- FIM DO MODAL EDITAR-->
      </section>
      <!-- /wrapper -->
    </section>











 
