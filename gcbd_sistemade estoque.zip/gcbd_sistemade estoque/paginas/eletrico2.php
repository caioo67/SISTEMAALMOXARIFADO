

   <section id="main-content">
      <section class="wrapper site-min-height">
        <h3><i class="fa fa-angle-right"></i> Material Eletrico</h3>

        <button style="margin-left:93%;" id="adicionarNOVO" type="button" class="btn btn-theme"  data-toggle="modal" data-target="#form_modal" data-whatever="@fat"> <i class="fa fa-plus-square-o" 
       ></i>  Novo
        </button>

      


        <div class="modal fade"  id="form_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Adicionar Produto</h5>
       <button type="button" class="close" data-dismiss="modal" aria-label="Close"> 
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
				<form method="POST" action="paginas/adicionarDados/adicionarEletrico.php">
					
				


              <div class="form-group">
            <label for="" class="col-form-label">Nome:</label>
            <input name="nome" type="text" class="form-control" placeholder="Digite o nome do produto...">
              </div>

          


              <div class="form-group">
							<label>Qyantidade de produtos:</label>
							<input type="text" name="qtdProduto"  class="form-control" required="required" />
						</div>

						
          


              <div class="form-group">
              <label class="col-form-label">Quantidade miníma de produtos</label>
              <select style="width:250px; font-size: 13px" name="qtdMinima"  class="form-control">
                <option value="" disabled="" selected="">Selecione a quantidade</option>
                <option value="05">05</option>
                <option value="10">10</option>
                <option value="15">15</option>
                <option value="20">20</option>
              </select>
               </div>



						
					<div style="clear:both;"></div>


       
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> 
        <button type="submit"  name="AdicionarEletrico" class="btn btn-warning">Adicionar</button>
      </div>
        
				
				</form>
        </div>

    </div>
  </div>
</div>
        

    <div class="row mt">
       <div class="col-lg-12">
                          
                        <table class="table table-striped" id="minhaTabela">
                                  <thead>
                                    <tr>
                                      <th>Nome</th>
                                      <th>Quantidade de produtos</th>
                                      <th>Quantidade minima</th>
                                       <th>Deletar</th>
                                      <th>Editar</th>
                                    </tr>
                                  </thead>
                                  <tbody>

                        <?php
                          require 'conn.php';
                          $query = mysqli_query($conn, "SELECT * FROM `meletrico`") or die(mysqli_error());
                          while($fetch = mysqli_fetch_array($query)){
                        ?>

                                    <tr>
                                      <td><?php echo $fetch['nome']?></td>
                                      <td><?php echo $fetch['qtdProduto']?></td>
                                      <td><?php echo $fetch['qtdMinima']?></td>

                                        <td><a href="paginas/delete/deleteEletrico.php?deletar=<?php echo $fetch['id']?>" class="btn btn-danger" onclick="return confirm('Deseja realmente deletar o Registro')"><i class="fa fa-trash-o"></i></a></td>

                                        <td><button id="adicionarNOVO" type="button" class="btn btn-warning"  data-toggle="modal" data-target=".bd-example-modal-sm"> <i class="fa fa-minus-square-o"></i></button></td>

                                      <td><button class="btn btn-warning" data-toggle="modal" type="button" data-target="#update_modal<?php echo $fetch['id']?>"><span class="glyphicon glyphicon-edit"></span> Edit</button></td>
                                    </tr>
                      <?php
                        
                        include 'modal_update/modalEletrico.php';
                          }
                        
                      ?>
                                    </tbody>
                          </table>
          </div>
    </div>  


<!-- MODAL DO RETIRAR-->
<div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
     <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"> Editar produto</h5>
       <button type="button" class="close" data-dismiss="modal" aria-label="Close"> 
          <span aria-hidden="true">&times;</span> 
        </button>
      </div>
    <form method="post">

 
         <div style="margin-left: 7%; " class="form-group">
            <label class="col-form-label">Quantidade:</label>
            <input  name="r"  type="text" class="form-control" placeholder="Quantidade de produtos...">
          </div>

      <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button> 
            <button type="submit"  name="botaoR" class="btn btn-warning">Retirar</button>
      </div>

</form>


        </div>

    </div>
</div>
</div>
<!-- FIM MODAL DO RETIRAR-->



<?php
include_once('includes/sair.php');
            if(isset($_POST['botaoR'])){
              $r = trim(strip_tags($_POST['r']));
                           
                   try{

                        $result = $conect->prepare($update="UPDATE meletrico SET qtdProduto = '- $r' WHERE id='$id'");
                        $result->bindParam(':id',$id,PDO::PARAM_INT);
                        $result->bindParam(':qtdProduto',$update,PDO::PARAM_STR);
           
                        $result->execute();

                        $contar = $result->rowCount();
                        if($contar>0){
                          echo '<div class="alert alert-success" role="alert">Dados atualizados com sucesso!</div>';
                        }else{
                          echo '<div class="alert alert-danger" role="alert">Dados não atualizados!</div>';
                        }
                    }catch(PDOException $e){
                        echo "<b>ERRO DE PDO= </b>".$e->getMessage();
                    }
            }

          ?>


      </section>
    </section>











